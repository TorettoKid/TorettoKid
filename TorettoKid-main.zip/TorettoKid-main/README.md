<div id="header" align="center">
  <a href="https://github.com/MrTamilKiD">
  <img src="https://media.giphy.com/media/M9gbBd9nbDrOTu1Mqx/giphy.gif" width="100"/>
  </a>
</div>

<div align="center">
  <a href="https://telegram.me/MrTamilKiD">
    <img src="https://img.shields.io/badge/Telegram-red?style=for-the-badge&logo=telegram&logoColor=white" alt="telegram Badge"/>
  </a>

</div>




<div id="badges" align="center" width="170px" height="24">
  <a href="https://github.com/MrTamilKiD">
    <img src="https://komarev.com/ghpvc/?username=kunsh13&label=PROFILE%20VISITORS&color=blueviolet&style=flat-square" alt="views Badge"/>
  </a>
  <a href="https://github.com/MrTamilKiD">
    <img src="https://komarev.com/ghpvc/?username=kunsh13&style=flat-square&color=blue" alt="avipatilpro" alt="Youtube Badge"/>
  </a>
</div>


<img src="https://readme-typing-svg.herokuapp.com?font=Kaushan+Script&size=40&duration=3500&color=447FF7&background=FFFFFF00&center=true&vCenter=true&width=650&height=55&lines=Hey!+It's+Happy+%F0%9F%91%8B%F0%9F%8F%BB;I'm+a+student,+coder+and+a+developer!+%F0%9F%A7%91%F0%9F%8F%BB%E2%80%8D%F0%9F%92%BB;⚡+Fun+fact+I'm+a+noob+coder+%F0%9F%87%AE%F0%9F%87%B3;I+am+from+India+%F0%9F%93%88;Please+Support+and+Follow+%E2%9A%99%EF%B8%8F" alt="Happy" width="650" height="55">

<h3 align="center">🔗Connect with me: </h3>
<!--[<img align="left" alt="TG" | telegram" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/telegram.svg" />][TELEGRAM] -->


<br>
  <div align="center" >
  <a href="https://github.com/MrTamilKiD">
    <img  width="120px" src="https://www.gstatic.com/telegram/img/branding/telegramlogo/svg/telegramlogo.svg" alt="Telegram Badge"/>
  </a>
  </div>
<br>

<br>



<h2 align="center">🧬 Languages and Tools: </h2>
<p align="center"><code><a href="https://www.w3schools.com/css/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="40" height="40"/></a></code> <code><a href="https://firebase.google.com/" target="_blank"><img src="https://www.vectorlogo.zone/logos/firebase/firebase-icon.svg" alt="firebase" width="40" height="40"/></a></code> <code><a href="https://git-scm.com/" target="_blank"><img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/></a></code> <code><a href="https://www.adobe.com/products/premiere.html" target="_blank"><img src="https://seeklogo.com/images/V/visual-studio-code-logo-284BC24C39-seeklogo.com.png" alt="Visual Studio Code" width="40" height="40"/></a></code> <code><a href="https://www.w3.org/html/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/1051/1051277.png?w=360" alt="html5" width="40" height="40"/></a></code> <code><a href="https://www.adobe.com/in/products/illustrator.html" target="_blank"><img src="https://www.adobe.com/content/dam/shared/images/product-icons/svg/illustrator.svg" alt="illustrator" width="40" height="40"/></a></code> <code><a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank"><img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/></a></code> <code><a href="https://www.python.org" target="_blank"><img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/></a></code> <code><a href="https://www.adobe.com/in/products/photoshop.html" target="_blank"><img src="https://www.adobe.com/content/dam/acom/one-console/icons_rebrand/ps_appicon.svg" alt="Photoshop" width="40" height="40"/></a></code> </p>





 




<br><br>
 
<h2 align="center"> 📊 ꜱᴛᴀᴛꜱ: </h2>



<div id="badges" align="center">
  <a href="https://github.com/MrTamilKiD">
    <img src="https://github-readme-stats.vercel.app/api?username=MrTamilKiD&bg_color=30,e96443,904e95&title_color=fff&text_color=fff" alt="LinkedIn Badge"/>
  </a>
  <br>
  <br>
  <a href="https://github.com/MrTamilKiD">
    <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=MrTamilKiD&bg_color=10,e96443,904e95&langs_count=10&hide_border=true&show_icons=true&title_color=fff&text_color=fff" alt="Youtube Badge"/>
  </a>
<br>
  <br>
  <a href="https://github.com/MrTamilKiD">
    <img src="http://github-readme-streak-stats.herokuapp.com?user=MrTamilKiD&theme=vue-dark&hide_border=true&date_format=j%20M%5B%20Y%5D" alt="Youtube Badge"/>
  </a>
</div>



